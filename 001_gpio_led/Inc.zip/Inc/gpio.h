#ifndef __GPIO_H
#define __GPIO_H

#include "stm32f4xx_hal.h"

void GPIO_LED_Init(void);

#endif
